from django.contrib.auth.forms import UserCreationForm, UserChangeForm,AuthenticationForm
from django.forms import ValidationError

from .models import CustomUser
from django import forms


class CustomUserCreationForm(UserCreationForm):
    #first_name=forms.CharField(max_length=50,required=True)

    class Meta:
        model = CustomUser
        fields = ('email','first_name', 'last_name','phone','is_active','is_staff')
        
    
    def clean_first_name(self):
        first_name=self.cleaned_data['first_name']
        print("first_name",first_name)
        first=None
        try:
           user=CustomUser.objects.get(first_name=first_name)
           print(first)

        except:
            return first_name
        
        if user is not None:
            raise ValidationError("First Name Already Exits!")
            
          
        
       
    
       
        
            


class CustomUserChangeForm(UserChangeForm):

    class Meta:
        model = CustomUser
        fields = ('email','first_name', 'last_name','phone','is_active','is_staff')
        
        

class LoginForm(AuthenticationForm):
    pass 
    
    