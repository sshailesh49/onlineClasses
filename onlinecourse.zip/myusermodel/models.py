from pyexpat import model
from django.db import models  
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin  
from django.utils import timezone  
#from django.utils.translation import gettext_lazy as _  
from .managers import CustomUserManager  
# Create your models here.  
  
class CustomUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(
        verbose_name='email address',
        max_length=255,
        unique=True,
    )
    first_name = models.CharField(max_length=70, null=True, blank=True)        
    last_name = models.CharField(max_length=70, null=True, blank=True)
    phone = models.CharField(max_length=10, null=True, blank=False,unique=True)  
    
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False) # a admin user; non super-user
    is_superuser = models.BooleanField(default=False) # a superuser
    last_login = models.DateTimeField(null=True, blank=True)
    date_joined = models.DateTimeField(auto_now_add=True)
    # notice the absence of a "Password field", that is built in.
    
    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    EMAIL_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name'] # Email & Password are required by default.
    
    class Meta:
        verbose_name = ('user')
        verbose_name_plural = ('users')
        #db_table = 'auth_user'
        abstract = False
    
    def get_absolute_url(self):
        return "/users/%i/" % (self.pk)
    
    @property
    def name(self):
        if self.first_name:
            return self.first_name
        
    
    def get_full_name(self):
        """
        Return the first_name plus the last_name, with a space in between.
        """
        full_name = '%s %s' % (self.first_name, self.last_name)
        return full_name.strip()

    def get_short_name(self):
        return self.email

    

    def __str__(self):              
        return self.email
    
    def natural_key(self):
        return (self.email,)

    def has_perm(self, perm, obj=None):
        return True

    def has_module_perms(self, app_label):
        return True



   
    
    