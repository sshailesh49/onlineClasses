
from django.urls import path
from courses.views.home import HomePage
from courses.views.coursepage import CoursePage
from courses.views.user_auth import SignUp,SignIn,signout,PasswordChange
from django.contrib.auth.views import PasswordChangeView
from courses.views.checkout import CheckOut,VerifyPayment
from django.urls import reverse_lazy


urlpatterns = [
    path("",HomePage.as_view(),name="home"),
    path("course/<str:slug>",CoursePage.as_view()),
    path("checkout/<str:slug>",CheckOut.as_view(),name='checkout'),
    path("signup",SignUp.as_view(),name="signup"),
    path("signin",SignIn.as_view(),name="signin"),
    path("signout",signout,name="signout"),
     # Change Password
    path('change-password',PasswordChange.as_view(),name='change_password'),
    
   path("verify_payment",VerifyPayment.as_view(),name="verify_payment"), 
    
   
]