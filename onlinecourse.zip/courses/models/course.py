
from enum import unique
from django.db import models

# Create your models here.
class Course(models.Model):
    name = models.CharField(max_length=30,null=False)
    slug=  models.CharField(max_length=30,null=False,unique=True)
    description  =  models.CharField(max_length=200,null=True,blank=True)
    price = models.IntegerField(null=False)
    discount = models.IntegerField(null=False,default=0)
    active = models.BooleanField(default=False)
    thumbnail = models.ImageField(upload_to="upload/thumbnail")
    date = models.DateTimeField(auto_now_add=True)
    resource = models.FileField(upload_to="upload/resouece",null="True",blank="True")
    length = models.IntegerField(null=True)
    
    def __str__(self):
        return self.name