from email.policy import default
from django.db import models
from courses.models.course import Course
from myusermodel.models import CustomUser

###
class UserCourse(models.Model):
    user=models.ForeignKey(CustomUser,null=False,on_delete=models.CASCADE)
    course=models.ForeignKey(Course,null=False,on_delete=models.CASCADE)
    date=models.DateTimeField(auto_now_add=True)
    class Meta:
        unique_together = ('user', 'course')
    
    
    def __str__(self): 
        return f'{self.user.email} -{self.course.name}'
    
    
   
    