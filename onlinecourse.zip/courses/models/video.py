from email.policy import default
from django.db import models
from courses.models.course import Course

###
class Video(models.Model):
    title=models.CharField(max_length=50,null=False)
    course=models.ForeignKey(Course,null=False,on_delete=models.CASCADE)
    video_url=models.CharField(max_length=20,null=False)
    serial_number=models.IntegerField(null=False)
    is_preview=models.BooleanField(default=False)