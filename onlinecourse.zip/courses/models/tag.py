from django.db import models
from courses.models.course import Course
#

class CourseProperty(models.Model):
    description=models.CharField(max_length=50,null=False)
    course=models.ForeignKey(Course,null=False,on_delete=models.CASCADE)
    class Meta:
        abstract=True
    
class Tag(CourseProperty):
    pass


class Prereqsite(CourseProperty):
    pass 

class Learning(CourseProperty):
    pass
