from courses.models import course
from courses.models import tag
from courses.models import video
#from courses.models import custom_user
from courses.models import user_course
from courses.models import payment
