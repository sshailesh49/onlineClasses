from email.policy import default
from django.db import models
from courses.models.course import Course
from myusermodel.models import CustomUser
from courses.models.user_course import UserCourse


###
class Payment(models.Model):
    order_id=models.CharField(max_length=50)
    payment_id=models.CharField(max_length=50,blank=True)
    user=models.ForeignKey(CustomUser,blank=True, null=True,on_delete=models.CASCADE)
    course=models.ForeignKey(Course,blank=True,null=True,on_delete=models.CASCADE)
    date=models.DateTimeField(auto_now_add=True)
    usercourse=models.ForeignKey(UserCourse,blank=True,null=True,on_delete=models.CASCADE)
    status=models.BooleanField(default=False)
    
    
    def __str__(self): 
        return f'{self.user.email} -{self.course.name}'
    
    
   
    