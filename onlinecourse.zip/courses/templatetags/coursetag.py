from django import template
register = template.Library()

from courses.models.user_course import UserCourse
##
@register.filter(name='discount')
def discount(price,discount):
    if discount is None or discount ==0:
        return price
    else:
        discount_price=price-(price*discount)/100
        return discount_price
 #second way 
 #<h1>{% sell_price i.price i.discount %}</h1>    ---use in html file 
@register.simple_tag    
def sell_price(price,discount):      
    if discount is None or discount ==0:
        return price
    else:
        discount_price=price-(price*discount)/100
        return discount_price  
    
    
# rupeee signechur

@register.filter(name="rupees")
def rupees(price):
    a="₹" +str(price)
    return a


@register.simple_tag    
def is_enrolled(request,course):
    if request.user.is_authenticated:
        is_enrolled=None
        try:
            is_enrolled=UserCourse.objects.get(user=request.user,course=course)
            return True
        except:
            return False
            
       
    
   
    
    else:
       
        return False