

from django.forms import ValidationError
from django.http import HttpResponse
from django.shortcuts import render, redirect, HttpResponseRedirect
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth.views import PasswordChangeView


from django.views import View
from myusermodel.forms import CustomUserCreationForm, CustomUserChangeForm, LoginForm
from myusermodel.models import CustomUser
from  django.contrib.auth.hashers import check_password
from django.contrib.auth import authenticate,logout,login

from django.contrib.messages.views import SuccessMessageMixin


class SignUp(View):
    def get(self, request):
        form = CustomUserCreationForm()
        return render(request, 'courses/signup.html', {'form': form})

    def post(self, request):
        form = CustomUserCreationForm(request.POST)
       
        if form.is_valid():
            user = form.save()
            return redirect('signin')

        return render(request, 'courses/signup.html', {'form': form})


class SignIn(View):
    return_url=None
    def get(self, request):
        
        
        form = LoginForm()
        SignIn.return_url=request.GET.get('return_url')
        

        return render(request, 'courses/signin.html', {"form": form})

    def post(self, request):
        
        form = LoginForm(request.POST)
        email=request.POST.get("username")
        password=request.POST.get("password")
        
        
        try:
            user=CustomUser.objects.get(email=email)
            
        except:
            error_message="Password Invalid Try Again!"
            return render(request,'courses/signin.html',{'error':error_message,"form":form})
         
         # You Use Two way    
        
        if user is not None and user.is_active==True:
            password_data=user.password
            #result= check_password(password,password_data)
            result=authenticate(request=request,username=email,password=password)
            if result is not None:
                login(request, user)
                
                if SignIn.return_url is not None:
                    return HttpResponseRedirect(SignIn.return_url)
                else:
                    
                 return redirect('home')
            else:
                 error_message=" Email or Password Invalid Try Again!"
                 return render(request,'courses/signin.html',{'error':error_message,"form":form})
           
            
        else:
           error_message="Your Account is  Disable!"
           return render(request,'courses/signin.html',{'error':error_message,"form":form})
            

def signout(request):
    logout(request)
    return redirect('home')


# d:/onlinecourse/myenv/Scripts/activate.bat

class PasswordChange(SuccessMessageMixin,PasswordChangeView):
        model = CustomUser
        form_class = PasswordChangeForm
        template_name = "courses/change-password.html"
        success_message = "Password Changed Successfully "
        success_url = "/"
