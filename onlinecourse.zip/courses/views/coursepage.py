from django.http import HttpResponse
from django.shortcuts import render,redirect

from django.views import View
from courses.models.course import Course
from courses.models.video import Video
from courses.templatetags.coursetag import is_enrolled
from django.urls import reverse



class CoursePage(View):
    
    def get(self,request,slug):
        return_url=request.META['PATH_INFO']
        print(return_url)
        
        
        course=Course.objects.get(slug=slug)
        video_list=course.video_set.all().order_by('serial_number')
        serial_number=request.GET.get('lacture')
        
        
        next_video=2
        previous_video=0
        if serial_number is None:
            serial_number=1
        
        else:
            
            
            next_video=int(serial_number)+1
            if len(video_list) < next_video:
                next_video=None
            
            previous_video=int(serial_number)-1
              
         
            
        
        video=Video.objects.get(serial_number=serial_number,course=course)
        
        enrolled=is_enrolled(request,course)
        
        
        if request.user.is_authenticated  is False and video.is_preview is False :
            return redirect(f'/signin?return_url={return_url}')
        elif enrolled is False and video.is_preview is False :
           return redirect(reverse('checkout', kwargs={ 'slug': course.slug }))
        
        else:
         return render(request,"courses/coursepage.html" ,{'course':course,'video':video, 'video_list':video_list,'next_video':next_video,'previous_video':previous_video})