
from django.http import HttpResponse
from django.shortcuts import render,redirect, HttpResponseRedirect



from django.views import View
from courses.models.course import Course
from onlinecourses.settings import *
from time import time
from courses.models.payment import Payment
from courses.models.user_course import UserCourse
from django.views.decorators.cache import cache_page
from django.views.decorators.csrf  import csrf_exempt
from django.utils.decorators import method_decorator
from django.urls import reverse



import razorpay
client = razorpay.Client(auth=(KEY_ID, KEY_SECRET))






class CheckOut(View):
    
    def get(self,request,slug):
    
        course=Course.objects.get(slug=slug)
        return_url=request.META['PATH_INFO']
       
        if not request.user.is_authenticated:
            return HttpResponseRedirect(f"/signin?return_url={return_url}")
        
        amount=(course.price-(course.price*course.discount)*0.01)*100
        user=request.user
        action=request.GET.get('action')
        order=None
        payment=None
        if action=='create_payment':
           DATA = { 
                   "amount": int(amount), 
                   "currency": "INR", 
                   "receipt": f"{user.first_name}bluechip{time()}",
                   "notes":{
                       "name":f"{user.first_name} {user.last_name}",
                       "email":user.email,
                       
                   }
                   
                   }
           order=client.order.create(data=DATA)
           OrderId=order.get('id')
           payment=Payment()
           payment.user=user
           payment.course =course
           payment.order_id= order.get('id')
           
           payment.save()
           
          
           
           
        
        return render(request,"courses/checkout.html",{"course":course,"order":order,'user':user})
        
        
#@method_decorator(csrf_exempt, name='dispatch')   
class VerifyPayment(View):
  
    def get(self,request):
        user=request.user
        usercourse=UserCourse.objects.filter(user=user)
        
        
            
        
        
            
            
            
           
            
    
            # payment=Payment()
            # payment.order_id=f"bluechip{data.get('razorpay_payment_id')}"
            # payment.payment_id=data.get('razorpay_payment_id')
            
            
            # payment.status=True
            
            # payment.save()
            # pay=None
            
            # try:
            #   pay=Payment.objects.get(payment_id= data.get('razorpay_payment_id'))
            
            
            # except:
            #     print(pay)
            #     return HttpResponse("invalid payment")
            
            # # usercourse=UserCourse()
        
            # # usercourse.save()
            
            
        
        return render(request,"courses/usercourse.html" ,{'usercourse':usercourse})
        
            



#d:/onlinecourse/myenv/Scripts/activate.bat