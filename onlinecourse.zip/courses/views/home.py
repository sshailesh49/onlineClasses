
from django.shortcuts import render,redirect

from django.views import View
from courses.models.course import Course



class HomePage(View):
    def get(self,request):
        get_courses=Course.objects.all()
        
        return render(request,'courses/home.html',{'courses':get_courses})
        



#d:/onlinecourse/myenv/Scripts/activate.bat