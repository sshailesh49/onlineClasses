from django.contrib import admin
from courses.models.course import Course
from courses.models.payment import Payment
from courses.models.tag import Tag,Learning,Prereqsite
from courses.models.video import Video
from courses.models.user_course import UserCourse



class PrereqsiteAdmin(admin.TabularInline):
    model=Tag

    
     

class LearningAdmin(admin.TabularInline):
    model=Learning
     
     
class TagAdmin(admin.TabularInline):
    model=Prereqsite
    list_display=("description","course")
#class VideoAdmin(admin.StackedInline):    
class VideoAdmin(admin.TabularInline):  
    model=Video
    

     

# Register your models here.
class CourseAdmin(admin.ModelAdmin):
    inlines = [PrereqsiteAdmin,TagAdmin,LearningAdmin,VideoAdmin]
    list_display=("id","name","description","price","discount","active","thumbnail","date","resource","length")
    list_filter=("active","price","date","name","length")
    search_fields=("id","name","active","price")
    date_hierarchy= "date"
    
# class PrereqsiteAdmin(admin.ModelAdmin):
#      list_display=("id","description","course")

# class LearningAdmin(admin.ModelAdmin):


#      list_display=("id","description","course")
     
# class TagAdmin(admin.ModelAdmin):
#      list_display=("id","description","course")


admin.site.register(Course,CourseAdmin)
# admin.site.register(Tag,TagAdmin)
# admin.site.register(Prereqsite,PrereqsiteAdmin)
admin.site.register(Video)
admin.site.register(Payment)
admin.site.register(UserCourse)

